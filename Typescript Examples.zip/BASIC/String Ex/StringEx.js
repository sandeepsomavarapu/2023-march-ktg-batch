var firstname = "International Business Machine Corporation";
var site = 'www.ibm.com';
//string concatenation
var str = 'Hello, my name is ' + firstname + 'and my site is ' + site;
console.log(str);
//String interpolation and multiline
var str2 = "Hello, my\n name is " + firstname + " \n and \nmy site\n is " + site;
console.log(str2);
