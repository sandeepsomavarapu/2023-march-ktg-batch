class ItemList<T>
{
private itemArray: Array<T>;
constructor() {
this.itemArray = [];
}
Add(item: T) : void {
this.itemArray.push(item);
}GetAll(): Array<T> {
    return this.itemArray;
    }
    }
    let fruits = new ItemList<string>();
    fruits.Add("Apple");
    fruits.Add("Mango");
    fruits.Add("Orange");
    let listOfFruits = fruits.GetAll();
    for (let i = 0; i < listOfFruits.length; i++) {
    console.log(listOfFruits[i]);
    }