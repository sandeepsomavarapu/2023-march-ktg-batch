
let list:string[] = ['one', 'two', "three"];
let [x, y, z] = list; 
//destructuring the array values into three variables x,y,z
console.log(x); // 'one'
console.log(y); // 'two'
console.log(z); // 'three'
console.log(`Array values are: ${x}, ${y}, ${z}`);
let obj = {a: 'one', b: 'two', c: 'three'};
let {a, b, c} = obj; 
// destructuring the object properties x, y, z
console.log(a); // 'one'
console.log(b); // 'two'
console.log(c); // 'three'