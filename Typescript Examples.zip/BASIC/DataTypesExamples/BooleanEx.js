var yes = true;
var no = false;
var a = "welcome to";
var b = "Type Script";
console.log(a + '' + b);
