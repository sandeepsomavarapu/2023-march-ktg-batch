class Person1
{
firsname;
lastname;
getFUllName()
{
    return this.firsname+" "+this.lastname;
}
}
  var p1=new Person1();
  
  p1.firsname="suresh";
  p1.lastname="kumar";
  
  console.log(p1.getFUllName());
  //console.log(p.firsname+" "+p.lastname);

