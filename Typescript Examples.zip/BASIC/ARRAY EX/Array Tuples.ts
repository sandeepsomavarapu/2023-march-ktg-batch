var arr :[number,boolean];
      

arr=[1,true];
arr=[10,false];
//arr=[true,'hello'];//invalid
//arr=[1];//invalid
//arr=[true,123];//invalid