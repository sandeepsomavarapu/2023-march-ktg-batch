var fname = 'International Business Machine Corporation`;
var website = `www.ibm.com`;
//string concatenation
var str1 =" Hello, my name is " + fname + 
"\n and my site is " + website;
console.log(str1);
