"use strict";
exports.__esModule = true;
//importing the namespace
var nampSpaceApp_1 = require("./nampSpaceApp");
//accessing Gurukulsight namespace student class
var Student = nampSpaceApp_1.School.Student;
//creating object of student class
var st = new Student(1, "Mohan");
console.log(st.showDetails());
