var Employee = /** @class */ (function () {
    function Employee(empid, name) {
        this.empid = empid;
        this.name = name;
    }
    Employee.prototype.displayDetails = function () {
        return this.empid + " : " + this.name + " " + Employee.orgName;
    };
    Employee.orgName = "capgemini";
    return Employee;
}());
var emp = new Employee(123, "suresh");
emp.empid = 12312;
var emp1 = new Employee(124, "naresh");
console.log(emp.displayDetails());
console.log(emp1.displayDetails());
