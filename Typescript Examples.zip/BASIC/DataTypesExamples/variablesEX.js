var a = 12;
var b;
var c;
var d;
var e = undefined;
var f = null;
a = 123;
b = 20;
c = "welcome";
d = false;
console.log(a - b);
console.log("welcome to typescript");
//these datatypes are primitve types in javascript and type script also
