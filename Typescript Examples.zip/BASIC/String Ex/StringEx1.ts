let fname: string = `International Business Machine Corporation`;
let website: string = `www.ibm.com`;
//string concatenation
let str1 =`Hello, my name is ${fname}
 and my site is ${website}`
console.log(str1);




