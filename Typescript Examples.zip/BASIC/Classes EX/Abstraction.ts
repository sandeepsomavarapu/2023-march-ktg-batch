class Employee {
    private passcode: string;
    private _fullName: string;
    constructor(_passcode?: string) {
    this.passcode = _passcode;
    }
    get fullName(): string { //accessing value
    return this._fullName;
    }
    set fullName(newName: string) { //setting value
    if (this.passcode == "dontsleep") {
    this._fullName = newName;
    }
    else {
    console.log("Error: Unauthorized update of employee!");
    }
    }
    }
    let e1 = new Employee("dontsleep");
    e1.fullName = "suresh kumar";
    if (e1.fullName) {
    console.log(e1.fullName);
    }