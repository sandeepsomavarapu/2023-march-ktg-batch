//exporting Employee type
export class Employee {
    constructor(private firstName:
         string, private lastName: string) { 
         }
    showDetails() {
    return this.firstName + ", " + this.lastName;
    }}
    
    //exporting Student type
    export class Student  {
    constructor(private rollNo: number, private name: string) { }
    showDetails() {
    return this.rollNo + ", " + this.name;
    }
    
}