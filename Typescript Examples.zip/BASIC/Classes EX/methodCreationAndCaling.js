var Person1 = /** @class */ (function () {
    function Person1() {
    }
    Person1.prototype.getFUllName = function () {
        return this.firsname + " " + this.lastname;
    };
    return Person1;
}());
var p1 = new Person1();
p1.firsname = "sandeep";
p1.lastname = "somavarapu";
console.log(p1.getFUllName());
//console.log(p.firsname+" "+p.lastname);
