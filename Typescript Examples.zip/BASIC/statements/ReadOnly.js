var Company = /** @class */ (function () {
    function Company(_name) {
        this.country = "India";
        this.name = _name;
    }
    Company.prototype.showDetails = function () {
        console.log(this.name + " : " + this.country);
    };
    return Company;
}());
var c1 = new Company("Dot Net Tricks Innovation");
c1.showDetails(); // Dot Net Tricks Innovation : India
c1.name = "IBM"; //Error, name can be initialized only within constructor
