var list = ['one', 'two', 'three'];
var x = list[0], y = list[1], z = list[2]; //destructuring the array values into three variables x,y,z
console.log(x); // 'one'
console.log(y); // 'two'
console.log(z); // 'three'
var obj = { a: 'one', b: 'two', c: 'three' };
var a = obj.a, b = obj.b, c = obj.c; // destructuring the object properties x, y, z
console.log(a); // 'one'
console.log(b); // 'two'
console.log(c); // 'three'
