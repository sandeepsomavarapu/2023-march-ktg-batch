//named function with number as return type
function add(x, y) {
    return x + y;
}
//anonymous function with number as return type
var sum = function (x, y) {
    return x + y;
};
console.log(sum(12, 13));
console.log(add(14, 15));
var sum1 = function (x, y) { return x + y; };
console.log(sum1(123, 234));
var sum2 = function (x, y) { return x + y; };
console.log(sum2(123, 234));
var sum3 = function (x, y) { return x + y; };
var a1 = sum3(123, 234);
console.log(a1);
var sum4 = function () { return console.log("function with out return type"); };
sum4();
