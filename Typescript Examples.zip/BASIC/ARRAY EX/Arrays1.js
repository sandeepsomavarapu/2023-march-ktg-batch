var num = 12;
//num='qwerty';
//creating normal array
var a1 = [1, 2, 3, 'a', true];
a1.push("suresh")

// in a variable we can take different types also....but in ts we can restrict the variable to take number,string ....
//array creation in ts
var x;
x = [1, 2, 3, 4];
for (var i in x) {
    console.log(i);
}
x=['a','b'];
x.push("10");
x.push('y');
num = x.pop();
//it will remove last element from array and returns.
var numberList = [1, 2, 3];
//OR
var numList = [1, 2, 3];
