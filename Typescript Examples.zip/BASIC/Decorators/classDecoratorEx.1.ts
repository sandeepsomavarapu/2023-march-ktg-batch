@sealed
//experimentalDeacorators
class Employee {
constructor(private firstName: string, private lastName: string) { }
showDetails() {
return this.firstName + ", " + this.lastName;
}
}