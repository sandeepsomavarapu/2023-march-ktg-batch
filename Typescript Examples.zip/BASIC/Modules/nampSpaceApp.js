"use strict";
exports.__esModule = true;
var School;
(function (School) {
    //exporting outside the namespace body
    var Student = /** @class */ (function () {
        function Student(rollNo, name) {
            this.rollNo = rollNo;
            this.name = name;
        }
        Student.prototype.showDetails = function () {
            return this.rollNo + ", " + this.name;
        };
        return Student;
    }());
    School.Student = Student;
    // Only available inside the namespace body
    var maxCount = 100;
    var Employee = /** @class */ (function () {
        function Employee(firstName, lastName) {
            this.firstName = firstName;
            this.lastName = lastName;
        }
        Employee.prototype.showDetails = function () {
            return this.firstName + ", " + this.lastName;
        };
        return Employee;
    }());
})(School = exports.School || (exports.School = {}));
