interface Person {
   firstName: string;
    lastName: string;
    sal:number;
    }
    class Employee1 implements Person {
    constructor(public firstName: string, public lastName: string,public sal:number) {
    }
    }