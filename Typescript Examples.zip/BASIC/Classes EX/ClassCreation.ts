class Person
{
firsname:string;
lastname:string;
constructor(){
  console.log("default constructor");
}

}

  var p=new Person();//object 
  
  p.firsname="suresh";
  p.lastname="kumar";

  console.log(p.firsname+" "+p.lastname);

