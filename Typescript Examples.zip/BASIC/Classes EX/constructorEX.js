var Person2 = /** @class */ (function () {
    function Person2(fname, lname) {
        this.fname = fname;
        this.lname = lname;
    }
    return Person2;
}());
var p = new Person2("SANDEEP", "SOMAVARAPU");
console.log(p.fname + " " + p.lname);
