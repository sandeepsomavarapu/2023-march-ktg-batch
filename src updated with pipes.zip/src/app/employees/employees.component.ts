import { Component } from '@angular/core';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent {
employee:any[];//ngFor
  constructor(){
    
    this.employee=[
      {eid:123,ename:"sandeep",gender:"male",dob:"12/03/1993",salary:19000},
      {eid:124,ename:"mahitha",gender:"female",dob:"08/22/1996",salary:45000},
      {eid:125,ename:"sunitha",gender:"female",dob:"11/26/1973",salary:92800},
      {eid:126,ename:"naresh",gender:"male",dob:"01/18/1999",salary:46000},
  ]

  }
}
