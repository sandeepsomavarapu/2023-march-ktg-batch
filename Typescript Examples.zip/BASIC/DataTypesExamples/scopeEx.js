function f2() {
    var a = 123;
    if (a > 100) {
        var a_1 = 234;
        //   a=a++;
        console.log(a_1); //234
    }
    console.log(a); //123
}
f2();
