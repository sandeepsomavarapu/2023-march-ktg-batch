//ECMA Script--->specififcation

//javscript



var x=123;

{
const x=125;
}
console.log(x);

const y=124