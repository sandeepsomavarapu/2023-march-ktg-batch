var a:number=12;
var b:number;
var c:string;
var d:boolean;
var e=undefined;
var f=null;
               
a=123;
b=20;
c="welcome";
d=false;

console.log(a-b);
console.log("welcome to typescript");
//these datatypes are primitve types in javascript and type script also


	