function greet({firstName, lastName}): void {
    console.log(`Hello, ${firstName} ${lastName}!`);
    }
    let p1 = { firstName: 'ramesh', lastName: 'Chauhan' };
    let p2 = { firstName: 'anand', lastName: 'kumar' };
    greet(p1) 
    greet(p2)