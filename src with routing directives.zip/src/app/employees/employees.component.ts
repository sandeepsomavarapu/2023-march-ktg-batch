import { Component } from '@angular/core';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent {
employee:any[];//ngFor
  constructor(){
    
    this.employee=[
      {eid:123,ename:"sandeep",salary:19000},
      {eid:124,ename:"mahesh",salary:45000},
      {eid:125,ename:"suresh",salary:92800},
      {eid:126,ename:"naresh",salary:46000},
  ]

  }
}
