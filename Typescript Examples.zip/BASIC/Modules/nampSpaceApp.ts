export namespace School {
    //exporting outside the namespace body
    export class Student {
    constructor(private rollNo: number, private name: string) { }
    showDetails() {
    return this.rollNo + ", " + this.name;
    }
    }
    // Only available inside the namespace body
    let maxCount: number = 100;
    class Employee {
    constructor(private firstName: string, private lastName: string) { }
    showDetails() {
    return this.firstName + ", " + this.lastName;
    }
    }
    }