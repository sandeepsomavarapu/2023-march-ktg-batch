console.log("welcome typescript");
