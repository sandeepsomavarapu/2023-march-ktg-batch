var orgName = 'capgemini';
console.log("welcome to typescript :" + orgName);
