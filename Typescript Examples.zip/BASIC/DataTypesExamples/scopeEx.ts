function f2()//ecma script specification,javscript implementation,ECMA2015,es6
{//arrow function,var,let,const
var a=123;

if(a>100)
{
    const a=234;
    //  a=a++;
   console.log(a); //234
}
console.log(a); //123
}
f2();