let yes: boolean = true;
let no: boolean = false;
let a:String="welcome to";
let b:String ="Type Script";

console.log(a +''+ b);