//if statement
if (true)
    console.log("if statement");

//do-while statement
    let i: number = 1;
    do {
    console.log("do..while loop");
    i++;
    } while (i <= 1);
    let j: number = 1;
//while statement
    while (j <= 1) {
    console.log("while loop");
    j++;
    }
 //for statement   
    for (let k: number = 1; k < 4; k++) {
    console.log(k)}