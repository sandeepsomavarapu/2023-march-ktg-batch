class Person {
    private firstName: string;
    private lastName: string;
    constructor(_firstName: string, _lastName: string) {
    this.firstName = _firstName;
    this.lastName = _lastName;
    }
    fullName(): string {
    return this.firstName + " " + this.lastName;
    }
    }
    class Employee extends Person {
    id: number;
    constructor(_id: number, _firstName: string, _lastName: string) {
    //calling parent class constructor
    super(_firstName, _lastName);
    this.id = _id;
                        }
showDetails(): void {
//calling parent class method
console.log(this.id + " : " + this.fullName());
}
}
let e1 = new Employee(1, "rajesh", "kumar");
e1.showDetails(); //1 :rajesh kumar