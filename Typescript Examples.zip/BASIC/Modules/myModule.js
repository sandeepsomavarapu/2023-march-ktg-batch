"use strict";
exports.__esModule = true;
//exporting Employee type
var Employee = /** @class */ (function () {
    function Employee(firstName, lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
    Employee.prototype.showDetails = function () {
        return this.firstName + ", " + this.lastName;
    };
    return Employee;
}());
exports.Employee = Employee;
//exporting Student type
var Student = /** @class */ (function () {
    function Student(rollNo, name) {
        this.rollNo = rollNo;
        this.name = name;
    }
    Student.prototype.showDetails = function () {
        return this.rollNo + ", " + this.name;
    };
    return Student;
}());
exports.Student = Student;
