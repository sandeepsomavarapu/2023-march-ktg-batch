//importing the namespace
import { School } from "./nampSpaceApp";
//accessing Gurukulsight namespace student class
import Student = School.Student;
//creating object of student class
let st = new Student(1, "Mohan");
st.showDetails();