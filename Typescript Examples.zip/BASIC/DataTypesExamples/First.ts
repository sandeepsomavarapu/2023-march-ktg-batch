var orgName:string='capgemini';

console.log("welcome to typescript :"+orgName)