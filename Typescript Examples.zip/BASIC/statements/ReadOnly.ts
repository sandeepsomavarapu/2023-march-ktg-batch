class Company {
    readonly country: string = "India";
    readonly name: string;
    constructor(_name: string) {this.name = _name;
}
showDetails() {
console.log(this.name + " : " + this.country);
}
}
let c1 = new Company("WIPRO");
c1.showDetails(); 
//c1.country="capgemini";
c1.name = "IBM"; //Error, name can be initialized only within constructor