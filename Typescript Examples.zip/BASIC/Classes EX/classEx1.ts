class Employee {//component
    empid: number;
    name: string;
    static orgName:string="capgemini";

    constructor(empid: number, name: string) {
    this.empid = empid;
    this.name = name;
   
    }
    
    displayDetails() {
    return this.empid + " : " + this.name+" "+Employee.orgName;
    }
    
    }
    var emp=new Employee(123,"suresh");
    emp.empid=12312;
    var emp1=new Employee(124,"naresh");
    console.log(emp.displayDetails());
    console.log(emp1.displayDetails());

