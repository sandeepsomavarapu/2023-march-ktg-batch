var Person = /** @class */ (function () {
    function Person() {
        console.log("default constructor");
    }
    return Person;
}());
var p = new Person(); //object 
p.firsname = "suresh";
p.lastname = "kumar";
console.log(p.firsname + " " + p.lastname);
