//importing the exported types Student and Employee from myModule file

import { Student, Employee } from "./myModule";



let st = new Student(1, "Mohan");
let result1 = st.showDetails();
console.log("Student Details :" + result1);



let emp = new Employee("qwerty", "hello");
let result2 = emp.showDetails();
console.log("Employee Details :" + result2);//@Override,@Autowired  -->decorator ,class --component 