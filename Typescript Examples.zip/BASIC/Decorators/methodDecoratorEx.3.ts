class ItemList {
    itemArray: Array<string>;
    constructor() {
    this.itemArray = [];
    }
    @log
    Add(item: string): void {
    this.itemArray.push(item);
    }
    GetAll(): Array<string> {
    return this.itemArray;
    }
    }