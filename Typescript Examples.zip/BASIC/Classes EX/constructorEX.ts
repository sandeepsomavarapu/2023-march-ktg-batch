class Person2
{
    fname;
    lname;
constructor(fname:string,lname:string)
{
this.fname=fname;
this.lname=lname;
}
}

  var p=new Person2("capgemini","chennai");

  
  console.log(p.fname+" "+p.lname);

