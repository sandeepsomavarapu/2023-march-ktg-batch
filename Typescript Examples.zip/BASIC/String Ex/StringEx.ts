let firstname: string = "International Business Machine Corporation";
let site: string = 'www.ibm.com';
let site1: string = 'www.ibm.com';
//string concatenation
let str = 'Hello, my name is ' + firstname + 'and my site is ' + site+'next site '+site1;
console.log(str);
//String interpolation and multiline
let str2= `Hello, my
 name is ${firstname} 
 and 
my site
 is ${site}`;
console.log(str2);





