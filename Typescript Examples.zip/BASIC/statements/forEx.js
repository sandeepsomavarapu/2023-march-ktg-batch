//For..in Statement
var list = [4, 5, 6];
for (var i in list) {
    console.log(i); //keys: "0", "1", "2"
    console.log(list[i]); //values: "4", "5", "6"
}
//For..Of Statement
var list1 = [4, 5, 6];
for (var _i = 0, list1_1 = list1; _i < list1_1.length; _i++) {
    var i = list1_1[_i];
    console.log(i); //values: "4", "5", "6",
}
