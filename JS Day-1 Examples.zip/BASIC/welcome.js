function display()
{
var a=123;
var b=124;
alert(a+b);

}//"123"