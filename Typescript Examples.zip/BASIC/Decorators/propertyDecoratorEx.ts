class Company {
    @ReadOnly
    name: string = "Dot Net Tricks";
    }
    let company = new Company();
    company.name = 'IBM'; // you can't change it's name
    console.log(company.name); 