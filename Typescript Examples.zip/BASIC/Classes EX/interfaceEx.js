var Employee1 = /** @class */ (function () {
    function Employee1(firstName, lastName, sal) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.sal = sal;
    }
    return Employee1;
}());
