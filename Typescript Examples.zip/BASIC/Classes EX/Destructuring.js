function greet(_a) {
    var firstName = _a.firstName, lastName = _a.lastName;
    console.log("Hello, " + firstName + " " + lastName + "!");
}
var p1 = { firstName: 'ramesh', lastName: 'Chauhan' };
var p2 = { firstName: 'anand', lastName: 'kumar' };
greet(p1);
greet(p2);
